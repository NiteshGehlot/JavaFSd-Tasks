package com.library;

public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "Java";  
		String s2 = "Java";  //string literal //JVM may or maynot create object if already present
		String s3 = new String("Java"); //string object  //JVM compulsory creates object
		String s4 = new String("Java");	
		System.out.println(s1);
		System.out.println(s2);
		
		//String object:-in heap memory ,the moment we write "new" object will be created ,it has some hashcode ,reference
		//and inside the object value(java) will be present
		//if we create another object(s3) with same value ,JVM will create another object  irrespective of the already value present(s4) in the heap memory 
		//String literal:-if we do not use new keyword and use literal we will have the object but this will be in SCP(String Constant Pool)
		//this SCP is in heap memory
		//if we create another literal(s2) with same value ,JVM will not create another object it will refer it to the already value present(s1) in the SCP 

		s2 = s2.concat("lang");
		System.out.println(s2);
		
		String str1 = new String("A");
		String str2 = new String("A");
		
		System.out.println(str1.compareTo(str2));
		//it compares the ASCII values and return the difference integer number between 2
		
		StringBuffer sb1 = new StringBuffer("Java");
		sb1.append("lang");
		System.out.println(sb1);
		System.out.println(sb1.reverse());
		System.out.println(sb1.replace(0, 1, "k"));
		
		
	}

}
