package com.library;

public class WrapperDemo {
	public static void main(String[] args) {
		
		int n1= 99;
		String s= "99";
		Integer i = new Integer(99);
		
		
		
		Integer j = new Integer("99");
		
		String s1 = i.toString();
		
	}

}
