package com.library;

public class Main {
	
	public static void main(String args[]) {
		
		Employee e1 = new Employee(101,"Nitesh",5000);
		System.out.println(e1);
		
		Employee e2 = new Employee(102,"Sumit",4000);
		System.out.println(e2);
		
		System.out.println(e1.equals(e2));    //compares hashcode
		
		System.out.println(e1==e2);    //alternative for equals method
		
		
		System.out.println(e1.hashCode());  //prints pure integer number
		System.out.println(e2.hashCode());
	}

}
	