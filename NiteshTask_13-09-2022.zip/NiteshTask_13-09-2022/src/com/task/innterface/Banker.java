package com.task.innterface;

public abstract class Banker implements Bank {

	public void passbookPrint() {
		System.out.println("print method by interface");
	}

}
