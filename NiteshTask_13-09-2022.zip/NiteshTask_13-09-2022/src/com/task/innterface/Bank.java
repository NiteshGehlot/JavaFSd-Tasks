package com.task.innterface;

public interface Bank {

	public abstract void passbookPrint();

	public abstract void depositeMoney();

}
