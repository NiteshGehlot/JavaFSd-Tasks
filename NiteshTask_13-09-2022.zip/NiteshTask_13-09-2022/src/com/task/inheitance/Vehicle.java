package com.task.inheitance;

public class Vehicle {

	public Vehicle() {
		super();
		System.out.println("Vehicle constuctor");

	}

	public void type() {
		System.out.println("Type method");
	}

	public void looks() {
		System.out.println("Looks method");
	}

}
