package com.task.abstraction;

public abstract class Cat {
	public abstract void cat();

	public void catMovement() {
		System.out.println("dance");
	}

}
