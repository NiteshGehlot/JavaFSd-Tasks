package com.task.abstraction;

public class Childclass {
	public void catMovement() {

		System.out.println("cat movement from Childclass");
	}

}
