import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-constumer',
  templateUrl: './custumer.component.html',
  styleUrls: ['./custumer.component.css']
})
export class CustumerComponent implements OnInit {

  @Input() 
  data:any;

  @Input()
  custumerInput:string="";
 
  @Output()
  eventobj:EventEmitter<string> = new EventEmitter();

  CustumerData:string="Welcome to Customer Data";

  sendData(data:any){

    this.eventobj.emit(this.CustumerData);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
