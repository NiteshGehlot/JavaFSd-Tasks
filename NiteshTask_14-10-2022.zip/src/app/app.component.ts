import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  parentData = "Hi  I am Parent";
  
  dataFromChild:string="";

  getData(data:any){
    console.log(data);

    this.dataFromChild = data;
  }
}
