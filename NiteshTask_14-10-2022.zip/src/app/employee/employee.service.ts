import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http:HttpClient) { }

  url:string = "http://localhost:3000/employees";

  getAll():Observable<employee[]>{
     return  this.http.get<employee[]>(this.url);   //all http method returns observable;
  }

  insert(empObject:employee){
    return this.http.post<employee>(this.url,empObject).subscribe((data:employee)=>{console.log('data from post'+data)});
  }


}
