export class employee{
    eid:number =0;
    ename:string = "";
    salary:number =0;
}