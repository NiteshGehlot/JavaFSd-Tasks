import { Component, OnInit } from '@angular/core';
import { employee } from './employee';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {


  emp:employee = new employee(); 

  empList:employee[] = [];

  constructor(private service:EmployeeService) { }

  ngOnInit(): void {
  }
  
  getFormData(data:employee){

    console.log("display the data");
  }

  insertFormData(data:employee){
    console.log("data from form"+data);
    this.service.insert(data);
  }

  getAllEmployees(){

    this.service.getAll().subscribe((employees : employee[])=>{this.empList = employees ; console.log(this.empList)});

  }

  

}
