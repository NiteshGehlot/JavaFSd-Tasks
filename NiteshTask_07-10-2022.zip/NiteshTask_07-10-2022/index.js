var x = true;
var y = "string"; // Error: Type 'string' is not assignable to type 'boolean'.
console.log(y);


  function sum(...args) {
    let sum = 0;
    for (let arg of args) sum += arg;
    return sum;
  }
  
  let x = sum(4, 9, 16, 25, 29, 100, 66, 77);

  Array.from("ABCDEFG")  