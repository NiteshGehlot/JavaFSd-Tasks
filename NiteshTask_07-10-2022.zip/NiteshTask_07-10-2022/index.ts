var t = true;
let sh = "string";
console.log(sh)

