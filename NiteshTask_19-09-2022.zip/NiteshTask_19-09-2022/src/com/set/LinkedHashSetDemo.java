package com.set;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetDemo {
	
	public static void main(String args[]) {
		
		Set<String> set = new LinkedHashSet<String>();
		set.add("Nitesh");
		set.add("Snehal");
		set.add("Sumit");
		set.add("Sahil");
		set.add("Nitesh");   //duplicate not allowed
		set.add(null);
		
		
		System.out.println(set);
		
	}

}
