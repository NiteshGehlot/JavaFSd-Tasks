package com.set;

import java.util.HashSet;
import java.util.Set;

public class EmployeeHashSet {
	
	public static void main(String args[]) {
		
		Set<Employee> set = new HashSet<Employee>();
		
		set.add(new Employee(101,"Nitesh",1000));
		set.add(new Employee(102,"Snehal",2000));
		set.add(new Employee(103,"Sumit",1300));
		set.add(new Employee(104,"Sahil",1500));
		
		System.out.println(set);
		
	
	}

}
