package com.map;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class HashTableDemo {

	public static void main(String[] args) {

		Map<Integer, String> map = new Hashtable();

		map.put(120, "Nitesh");
		map.put(110, "Snehal");
		map.put(140, "Sumit");
		map.put(150, "Sahil");
		map.put(null, "Java"); // overrides value

		System.out.println(map);

	}

}
